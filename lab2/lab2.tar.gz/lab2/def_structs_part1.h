#ifndef __DEF_STRUCTS_H__
#define __DEF_STRUCTS_H__

struct userdef_work_t
{
	int x;
};

struct userdef_result_t
{
	double k;
};

#endif
