#ifndef __DEF_STRUCTS_H__
#define __DEF_STRUCTS_H__

struct userdef_work_t
{
	int *inp;
	int start, end;
};

struct userdef_result_t
{
	int max;
};

#endif

